# TNK-M11-PRO-C82

Class 82 code

To run the project follow the below commands:

```
* git clone https://github.com/Tynker-Blockchain/TNK-M10-PRO-C82-PCP-BP.git
* cd TNK-M11-PRO-C82-PCP-BP
* python3 -m venv myenv
* source myenv/bin/activate ( For Linux & Mac )
* myenv/Scripts/activate.bat ( Windows )
* pip install -r requirements.txt
* python3 app.py
```
